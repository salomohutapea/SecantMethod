#include <stdio.h>
#include <tgmath.h>
#include <math.h>

float f(float x)
{
    return(pow(1.5, x) - 5);
}

float main()
{
    float a,b,c,d,e;
    int count=1,n;
    printf("\n\nEnter the values of a and b:\n"); //(a,b) must contain the solution.
    scanf("%f%f",&a,&b);
    printf("Enter the values of allowed error and maximum number of iterations:\n");
    scanf("%f %d",&e,&n);
    do
    {
        if(f(a)==f(b)) {
            printf("\nSolution cannot be found as the values of a and b are same.\n");
            return 0;
        }
        c=(a*f(b)-b*f(a))/(f(b)-f(a));
        a=b;
        b=c;
        printf("\nIteration No-%d    x = %f\n",count,c);
        printf("The error at iteration no-%d is %f", count, fabs(f(c)));
        count++;
        if(count==n)
        {
            break;
        }
        printf("\n");
    } while(fabs(f(c)) > e);
    printf("\nAfter %d iterations, root = %8.6f\n",count-1,c);
}